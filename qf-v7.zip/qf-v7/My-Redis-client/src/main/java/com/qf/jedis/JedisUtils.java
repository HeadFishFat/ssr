package com.qf.jedis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class JedisUtils {


        private static JedisPool pool;

        static{

            JedisPoolConfig config = new JedisPoolConfig();

            config.setMaxIdle(100);

            config.setMaxWaitMillis(2000);

            config.setMaxTotal(200);

            String path = "192.168.2.128";

            pool = new JedisPool(config,path);

        }


    public static Jedis getJedisFromPoll(){

        return pool.getResource();

    }

}
