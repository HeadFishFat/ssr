package com.qf;

import redis.clients.jedis.Jedis;

public class redis {

    public static void main(String[] args) {


        Jedis jedis = new Jedis("192.168.241.128",6379);

        //jedis.auth("pangtouyu");

        jedis.set("你妈买菜","必涨价");

        String 你妈买菜 = jedis.get("你妈买菜");

        System.out.println(你妈买菜);

    }
}
