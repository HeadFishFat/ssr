package com.qf.v4.register.api;

import com.qf.dto.ReslutBean;
import com.qf.v4.register.vo.RegistUserVO;

public interface RegisterService {


    ReslutBean registerUser(RegistUserVO user);
}
