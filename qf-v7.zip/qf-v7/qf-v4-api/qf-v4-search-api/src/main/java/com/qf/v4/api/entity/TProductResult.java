package com.qf.v4.api.entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class TProductResult implements Serializable {

    private Long id;
    private String tName;
    private BigDecimal tPrice;
    private String salePoint;
    private String productDesc;
    private String tImage;

    @Override
    public String toString() {
        return "TProductResult{" +
                "id=" + id +
                ", tName='" + tName + '\'' +
                ", tPrice=" + tPrice +
                ", salePoint='" + salePoint + '\'' +
                ", productDesc='" + productDesc + '\'' +
                ", tImage='" + tImage + '\'' +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String gettName() {
        return tName;
    }

    public void settName(String tName) {
        this.tName = tName;
    }

    public BigDecimal gettPrice() {
        return tPrice;
    }

    public void settPrice(BigDecimal tPrice) {
        this.tPrice = tPrice;
    }

    public String getSalePoint() {
        return salePoint;
    }

    public void setSalePoint(String salePoint) {
        this.salePoint = salePoint;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String gettImage() {
        return tImage;
    }

    public void settImage(String tImage) {
        this.tImage = tImage;
    }

    public TProductResult(Long id, String tName, BigDecimal tPrice, String salePoint, String productDesc, String tImage) {
        this.id = id;
        this.tName = tName;
        this.tPrice = tPrice;
        this.salePoint = salePoint;
        this.productDesc = productDesc;
        this.tImage = tImage;
    }

    public TProductResult() {
    }
}
