package com.qf.v4.api;

import com.qf.dto.ReslutBean;
import com.qf.v4.api.entity.TProductResult;

import java.util.List;

public interface ISearchService{

    ReslutBean infoSolrData();

    ReslutBean initToSolr(TProductResult tProductResult);

    ReslutBean<List<TProductResult>> selectByKeywords (String keyword);
}
