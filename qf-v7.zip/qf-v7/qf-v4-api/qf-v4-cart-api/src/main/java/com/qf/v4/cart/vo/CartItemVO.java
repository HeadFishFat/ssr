package com.qf.v4.cart.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 存入到redis中的数据类型
 */
public class CartItemVO implements Serializable {

    private Long productId;
    private int count;
    private Date update_time;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }
}
