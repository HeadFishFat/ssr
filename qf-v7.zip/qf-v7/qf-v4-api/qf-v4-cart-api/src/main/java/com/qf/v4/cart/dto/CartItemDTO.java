package com.qf.v4.cart.dto;

import com.qf.entity.TProduct;

import java.io.Serializable;
import java.util.Date;


/**
 * 数据传输类型
 */
public class CartItemDTO implements Serializable {

    private TProduct product;
    private int count;
    private Date update_time;

    public TProduct getProduct() {
        return product;
    }

    public void setProduct(TProduct product) {
        this.product = product;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }
}
