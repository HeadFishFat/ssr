package com.qf.v4.cart.api;


import com.qf.dto.ReslutBean;

/**
 * 购物车
 */
public interface ICartService {


    //添加
    ReslutBean addProductToCart(Long productId, int count, String key);

    //查看购物车
    ReslutBean getCart(String key);

    //更新购物车
    ReslutBean updateCarat(String key, Long productId, int count);

    //根据id删除商品
    ReslutBean deleteCartById(String key, Long productId);
}
