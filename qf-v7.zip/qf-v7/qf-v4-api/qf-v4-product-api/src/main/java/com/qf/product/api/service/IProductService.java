package com.qf.product.api.service;

import com.qf.base.IBaseService;
import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;
import com.qf.product.api.dto.ProductDTo;

import java.util.List;

public interface IProductService extends IBaseService<TProduct> {


    List<TProduct> selectProducts();

    Long save(ProductDTo dto);

    Long updateById(ProductDTo dTo);

    ReslutBean selectById(Long id);
}
