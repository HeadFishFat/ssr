package com.qf.product.api.dto;

import com.qf.entity.TProduct;
import com.qf.entity.TProductDetails;

import java.io.Serializable;


/**
 * 商品添加操作实体类
 */
public class ProductDTo implements Serializable {

    private TProduct product;

    private TProductDetails details;

    private String productDesc;

    @Override
    public String toString() {
        return "ProductDTo{" +
                "product=" + product +
                ", details=" + details +
                ", productDesc='" + productDesc + '\'' +
                '}';
    }

    public TProduct getProduct() {
        return product;
    }

    public void setProduct(TProduct product) {
        this.product = product;
    }

    public TProductDetails getDetails() {
        return details;
    }

    public void setDetails(TProductDetails details) {
        this.details = details;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public ProductDTo(TProduct product, TProductDetails details, String productDesc) {
        this.product = product;
        this.details = details;
        this.productDesc = productDesc;
    }

    public ProductDTo() {
    }
}
