package com.qf.v4.sms.api;


import com.qf.dto.ReslutBean;

public interface ISMSService {

    ReslutBean sendSMS(String phone);
}
