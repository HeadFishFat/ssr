package com.qf.v4.item.api;

import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;

import java.util.List;


public interface ItemService {

    //生成静态页面
    ReslutBean initDetail(TProduct tProduct);

    //多线程生成静态页面
    ReslutBean batchGenerateDetail(List<TProduct> tProduct);

}
