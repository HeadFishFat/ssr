package api;


import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;

public interface IEmailService {

    ReslutBean sendMail(TUser user);

}
