package com.qf.v4.api;

import com.qf.base.IBaseDao;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;

public interface IUserService extends IBaseDao<TUser> {

    TUser Login(TUser user);

    ReslutBean checkIsLogin(String uuid);

    ReslutBean Logout(String uuid);

    Long save(TUser user);

    int addUser(TUser user);

    ReslutBean updateUserFlag(Long id);

    int smsAddUser(TUser tUser);
}
