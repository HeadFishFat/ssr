package com.qf.qfv4index.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.qf.constant.Cookiekeys;
import com.qf.entity.TProductType;
import com.qf.v4.api.IProductTypeService;
import com.qf.v4.api.IUserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
public class IndexController {

    @Reference
    private IProductTypeService iProductTypeService;

    @Reference
    private IUserService userService;

    @RequestMapping("list")
    public String getListByProduct(Model model){

        List<TProductType> list = iProductTypeService.List();
        System.out.println(list);
        model.addAttribute("TypesList",list);
        return "index";
    }

    /**
     * 注销
     * @param uuid
     * @param response
     * @return
     */
    @RequestMapping("logout")
    public String logout(@CookieValue(name ="user_login")String uuid,
                         HttpServletResponse response){

        System.out.println("传入的cookie = "+uuid);
        userService.Logout(uuid);

        //要把cookie给删掉
        Cookie cookie = new Cookie(Cookiekeys.COOKIE_USER_LOGIN,"");
        cookie.setMaxAge(0);
        //cookie.setDomain("qf.com");
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
        System.out.println("用户注销");
        return "index";
    }


    /**
     * 登陆首页测试
     * @return
     */
    @RequestMapping("index")
    public String LoginIndex(){

        return "index";
    }


    @RequestMapping("SearchList")
    public String searchList(){

        return "SearchList";
    }
}
