package com.qf.qf.v4.cart.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.qf.constant.Cookiekeys;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import com.qf.v4.cart.api.ICartService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

@Controller
public class ICartController {

    @Reference
    private ICartService cartService;


    /**
     * 抽取的 设置cookie返回方法
     * @param key
     * @param response
     */
    public void  setCookie(String key,HttpServletResponse response){
        Cookie cookie = new Cookie(Cookiekeys.USER_CART,key);
        cookie.setMaxAge(30*24*60*60);
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
    }
    /**
     * 添加购物车
     * @param productId
     * @param count
     * @param key
     * @param response
     * @return
     */
    @RequestMapping("/add/{productId}/{count}")
    @ResponseBody
    public ReslutBean addProduct(@PathVariable("productId") Long productId,
                                 @PathVariable("count") int count,
                                 @CookieValue(value = Cookiekeys.USER_CART,required = false) String key,
                                 HttpServletResponse response, HttpServletRequest request){

        //从request域中获取user
        Object user = request.getAttribute("user");
        if (user!=null){
            TUser user1 = (TUser) user;
            //组织键
            ReslutBean reslutBean = cartService.addProductToCart(productId, count, user1.getId().toString());
            return reslutBean;
        }


        //未登录购物车
        if (key==null||key.equals("")){
            //如果为空 创建uuid
             key = UUID.randomUUID().toString();
        }

        //添加
        ReslutBean reslutBean = cartService.addProductToCart(productId, count, key);

        //设置cookie
        setCookie(key,response);

        return  reslutBean;
    }


    /**
     * 查看购物车
     * @param key 前端传入的uuid
     * @param response 返回cookie
     * @return
     */
    @RequestMapping("getCart")
    @ResponseBody
    public ReslutBean getRedisCart(@CookieValue(value = Cookiekeys.USER_CART,required = false)String key,
                                   HttpServletResponse response,HttpServletRequest request){

        Object user = request.getAttribute("user");
        System.out.println(user);
        if (user!=null){
            TUser user1 = (TUser) user;
            Long id = user1.getId();
            //去service
            ReslutBean reslutBean = cartService.getCart(id.toString());
            return reslutBean;
        }


        if (key == null){
            return ReslutBean.error("用户购物车内没有商品");
        }

        ReslutBean reslutBean = cartService.getCart(key);

        //更新cookie的时间
        setCookie(key,response);

        return  reslutBean;
    }

    /**
     * 更新购物车
     * @param key
     * @param productId
     * @param count
     * @return
     */
    @RequestMapping("updateCart/{productId}/{count}")
    @ResponseBody
    public ReslutBean updateProductToCart(@CookieValue(name = Cookiekeys.USER_CART,required = false)String key,
                                          @PathVariable("productId") Long productId,
                                          @PathVariable("count") int count){

        //判断是否为空
        if (key==null){
            return ReslutBean.error("该用户没有购物车");
        }
        //去更新数量
        ReslutBean reslutBean = cartService.updateCarat(key, productId, count);
        return reslutBean;
    }

    /**
     * 根据id删除购物车商品
     * @param key
     * @param productId
     * @param response
     * @return
     */
    @RequestMapping("del/{productId}")
    @ResponseBody
    public ReslutBean deleteCartById(@CookieValue(name = Cookiekeys.USER_CART,required = false)String key,
                                     @PathVariable("productId") Long productId,
                                     HttpServletResponse response){

        System.out.println("前端传入的cookie:"+key);
        if (key==null){
            return  ReslutBean.error("用户没有购物车");
        }
        ReslutBean reslutBean = cartService.deleteCartById(key, productId);

        //设置cookie
        setCookie(key,response);

        return reslutBean;
    }
}
