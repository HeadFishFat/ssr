package com.qf.v4.product.web.consumer.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;


/**
 * Dropzone的配置文件
 */
@Configuration
public class WebConfig {

    @Bean
    public CommonsMultipartResolver getResolver(){
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        //设置上传大小
        resolver.setMaxUploadSize(10485760L);
        return resolver;
    }
}
