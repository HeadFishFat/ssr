package com.qf.v4.product.web.consumer.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.github.pagehelper.PageInfo;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;
import com.qf.entity.TProductDetails;
import com.qf.product.api.dto.ProductDTo;
import com.qf.product.api.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class ProductController {

    @Value("${image.http}")
    public String IMAGE_HTTP;

    @Reference
    private IProductService productService;

    @Autowired
    private FastFileStorageClient fileStorageClient;

    @RequestMapping("/product/{id}")
    @ResponseBody
    public ReslutBean getProductById(@PathVariable("id") Long id){

        ReslutBean tProduct = productService.selectById(id);
        System.out.println("ajax+++"+tProduct);


        return tProduct;
    }


    /**
     * 分页接口
     * @param pageNum  当前是第几页
     * @param pageSize  每页显示的记录条数
     * @return
     */
    @RequestMapping("product/page/{pageNum}/{pageSize}")
    public String getProductsByPage(@PathVariable int pageNum,
                                    @PathVariable int pageSize,
                                    Model model){

        PageInfo<TProduct> pageInfo = productService.getPageInfo(pageNum,pageSize);

        //传输到前端的
        model.addAttribute("pageInfo",pageInfo);

        return "products";
    }


    /**
     * 获得所有商品列表并返回商品列表页
     * @param model
     * @return
     */
    @RequestMapping("products")
    public String products(Model model){
        List<TProduct> list = productService.selectProducts();
        model.addAttribute("products",list);
        return "products";
    }

    /**
     * 添加商品,已实现
     * @param dto
     * @param
     * @return
     */
    @RequestMapping(value = "product/add",method = RequestMethod.POST)
    public String addProduct(ProductDTo dto){
        System.out.println(dto);
        //获得dto中product
        TProduct product = dto.getProduct();
        //手动封装数据,后期到数据库拿所属品牌
        Long typeId = dto.getProduct().getTypeId();
        if (typeId==1){
            product.setTypeName("电器装备电缆");
        }else if (typeId==2){
            product.setTypeName("电力电缆");
        }else if (typeId==3){
            product.setTypeName("通讯光缆");
        }
        //获得回显id
        Long productId = productService.save(dto);
        System.out.println(productId);
        return "redirect:/product/page/1/5";
    }


    /**
     * 删除接口
     * @param id
     * @return
     */
    @RequestMapping("product/del/{id}")
    public String delProduct(@PathVariable Long id){

        productService.deleteByPrimaryKey(id);

        return "redirect:/product/page/1/5";
    }

    /**
     * 修改
     * @param dTo
     * @return
     */
    @RequestMapping("/product/update")
    public String updateById(ProductDTo dTo){

        System.out.println("dto模型++"+dTo);
        //获得dto中product
        TProduct product = dTo.getProduct();
        //手动封装数据,后期到数据库拿所属品牌
        Long typeId = dTo.getProduct().getTypeId();
        if (typeId==1){
            product.setTypeName("电器装备电缆");
        }else if (typeId==2){
            product.setTypeName("电力电缆");
        }else if (typeId==3){
            product.setTypeName("通讯光缆");
        }
        product.setId(product.getId());

        TProductDetails details = dTo.getDetails();
        details.setPid(product.getId());

        Long productId = productService.updateById(dTo);
        System.out.println(productId);

        return "redirect:/product/page/1/5";
    }

}
