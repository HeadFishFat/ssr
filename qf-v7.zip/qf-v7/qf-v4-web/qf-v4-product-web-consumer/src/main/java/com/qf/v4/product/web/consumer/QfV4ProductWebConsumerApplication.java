package com.qf.v4.product.web.consumer;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import com.github.tobato.fastdfs.FdfsClientConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(FdfsClientConfig.class)
@EnableDubbo
public class QfV4ProductWebConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(QfV4ProductWebConsumerApplication.class, args);
    }

}
