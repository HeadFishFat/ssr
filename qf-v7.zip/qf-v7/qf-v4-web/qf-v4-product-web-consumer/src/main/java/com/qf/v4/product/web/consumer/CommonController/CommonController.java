package com.qf.v4.product.web.consumer.CommonController;


import com.github.tobato.fastdfs.service.FastFileStorageClient;
import com.qf.dto.ReslutBean;
import com.qf.utils.ImageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@Controller
public class CommonController {

    @Autowired
    private FastFileStorageClient client;

    @Value("${image.http}")
    private String IMAGESERVER;


    /**
     * Dropzone图片上传
     * @param file 传入的图片
     * @return
     */
    @RequestMapping(value = "/uploadImage",method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> getFilePath(MultipartFile file){
        //调用封装的工具类生成图片地址
        String imagePath = ImageUtils.filePath(client, IMAGESERVER, file);
        //new一个map将图片地址存入
        Map<String,Object> result = new HashMap<>();

        result.put("imagePath",imagePath);

        return result;
    }

    /**
     * wangEditor
     * @param file 传入的富文本框图片
     * @return
     */
    @RequestMapping(value = "/uploadImageByEditor",method = RequestMethod.POST)
    @ResponseBody
    public ReslutBean uploadImageByEditor(MultipartFile file){
        //System.out.println(files);
        //通过图片地址拼接工具转化成图片地址
        ReslutBean bean = new ReslutBean();

        //上传多张图片
        //String[] imagePath = ImageUtils.filePathArr(client, IMAGESERVER, files);

        String imagePath = ImageUtils.filePath(client, IMAGESERVER,file);

        bean.setErrno(0);


        //bean.setData(imagePath);
        bean.setData(new String[]{imagePath});

        System.out.println(bean);

        return bean;

    }

}
