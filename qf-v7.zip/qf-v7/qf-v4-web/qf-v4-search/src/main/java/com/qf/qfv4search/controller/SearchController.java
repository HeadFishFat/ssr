package com.qf.qfv4search.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.qf.dto.ReslutBean;
import com.qf.v4.api.ISearchService;
import com.qf.v4.api.entity.TProductResult;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("Search")
public class SearchController {


    @Reference
    private ISearchService searchService;

    @RequestMapping("show")
    public String show(){

        return "SearchList";
    }


    /**
     * 将数据库的数据插入索引库
     * @return
     */
    @RequestMapping("infoSolrData")
    @ResponseBody
    public ReslutBean infoSolrData(){
        ReslutBean reslutBean = searchService.infoSolrData();
        System.out.println(reslutBean);
        return reslutBean;
    }

    /**
     * 查询关键字显示高亮
     * @param keywords 前端传入的关键字
     * @return
     */
    @RequestMapping("keywords")
    public String selectByKeywords(String keywords, Model model){

        System.out.println(keywords);
        ReslutBean<List<TProductResult>> reslutBean = searchService.selectByKeywords(keywords);
        model.addAttribute("products",reslutBean.getData());

        System.out.println(reslutBean.getData());
        return  "SearchList";
    }
}
