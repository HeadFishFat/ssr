package com.qf.qf.v4.register.controller;


import api.IEmailService;
import com.alibaba.dubbo.config.annotation.Reference;
import com.qf.constant.Cookiekeys;
import com.qf.constant.Rediskeys;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import com.qf.utils.StringUtils;
import com.qf.v4.api.IUserService;
import com.qf.v4.register.api.RegisterService;
import com.qf.v4.register.vo.RegistUserVO;
import com.qf.v4.sms.api.ISMSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping("register")
public class RegisterController {

    @Autowired
    private RedisTemplate redisTemplate;

    @Reference
    private IEmailService service;

    @Reference
    private IUserService userService;

    @Reference
    private ISMSService ismsService;

    @Reference
    private RegisterService registerService;

    /**
     * 注册页测试
     * @return
     */
    @RequestMapping("register")
    public String show(){

        return "register";
    }
    /**
     * 用户注册flag为0
     */
    @RequestMapping("userLogin")
    public String userLogin(TUser user, HttpServletResponse response){

        System.out.println(user.getEmail());
        System.out.println(user.getPassword());


        //添加注册未激活用户,获得回显id
        int id = userService.addUser(user);
        System.out.println("回显id:"+id);
        //创建一个键
        String uuid = UUID.randomUUID().toString();

        String key = StringUtils.splicingString(Rediskeys.EMAIL_REGISTER_TOKEN, uuid);

        //将user对象存入redis
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.opsForValue().set(key,id);
        //设置超时时间
        redisTemplate.expire(key,30, TimeUnit.MINUTES);

        Cookie cookie = new Cookie(Cookiekeys.COOKIE_EMAIL_REGISTER,key);
        cookie.setHttpOnly(true);
        cookie.setMaxAge(30);
        cookie.setPath("/");
        response.addCookie(cookie);

        return "redirect:http://localhost:8091/user/toLogin";
    }

    /**
     * 邮箱注册:验证用户并激活
     * @param request
     * @return
     */
    @RequestMapping("checkingNO")
    public ReslutBean checkingEmail(HttpServletRequest request){

        //获得前端的uuid
        Cookie[] cookies = request.getCookies();
        if (cookies != null){
            for (Cookie cookie : cookies) {
                //获得邮箱验证的uuid
                if (cookie.getName().equals(Cookiekeys.COOKIE_EMAIL_REGISTER)){
                    String uuid = cookie.getValue();
                    //拼接rediskey
                    String key = StringUtils.splicingString(Rediskeys.EMAIL_REGISTER_TOKEN, uuid);
                    redisTemplate.setKeySerializer(new StringRedisSerializer());
                    //去redis中查询
                    Long id = (Long) redisTemplate.opsForValue().get(key);

                    ReslutBean reslutBean = userService.updateUserFlag(id);
                    reslutBean.setErrno(0);
                    reslutBean.setMessage("注册成功");
                    return reslutBean;
                }
            }
        }
        return ReslutBean.error("注册失败");
    }

    /**
     * 邮箱验证修改flag
     * @param id
     * @return
     */
    @RequestMapping("/checking/{id}")
    @ResponseBody
    public ReslutBean checkingEmailNew(@PathVariable("id") Long id){

        System.out.println("id:"+id);
        ReslutBean reslutBean = userService.updateUserFlag(id);
        return reslutBean;

    }

    /**
     * 短信验证
     * @param phone 用户手机号码
     * @return
     */
    @RequestMapping(value = "/getCode/{phone}",method = RequestMethod.GET)
    @ResponseBody
    public ReslutBean getCode(@PathVariable String phone){

        System.out.println("需要注册的手机号:"+phone);

        ReslutBean resultBean = ismsService.sendSMS(phone);

        return resultBean;
    }


    /**
     * 验证短信验证码并创建用户
     * @param user
     * @return
     */
    @PostMapping("/user")
    @ResponseBody
    public ReslutBean registerUser(RegistUserVO user){

        System.out.println(user.getPhone());
        System.out.println(user.getCode());
        System.out.println(user.getPassword());


        ReslutBean reslutBean = registerService.registerUser(user);
        return reslutBean;

    }

}
