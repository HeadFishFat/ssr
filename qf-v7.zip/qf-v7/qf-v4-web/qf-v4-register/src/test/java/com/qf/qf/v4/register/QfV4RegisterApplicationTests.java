package com.qf.qf.v4.register;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QfV4RegisterApplicationTests {

    @Test
    public void contextLoads() {
    }

}
