package com.qf.qfv4sso.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.qf.constant.Cookiekeys;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import com.qf.utils.StringUtils;
import com.qf.v4.api.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping("user")
public class UserController {

    @Reference
    private IUserService userService;


    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 首页跳转
     * @return
     * */

    /**
     * 登陆页面跳转
     * @return
     */
    @RequestMapping("toLogin")
    public String Login(){

        return "Login";
    }

    /**
     * 注册页跳转
     * @return
     */
    @RequestMapping("toRegister")
    public String Register(){

        return "Register";
    }

    /**
     * 注册
     * @param user
     * @return
     */
    @PostMapping("Register")
    public String userRegister(TUser user){

        Long id = userService.save(user);

        System.out.println("回显id"+id);

        return "redirect:http://localhost:8092/user/list";
    }


    /**
     * 登陆验证,登陆页面跳转首页
     * @param user 用户账户
     * @param response 密码
     * @return
     */
    @PostMapping("checkLogin")
    public String userLogin(TUser user, HttpServletResponse response){

        System.out.println(user);
        //先验证用户是否存在然后验证密码
        TUser tUser = userService.Login(user);
        System.out.println(tUser);
        //验证非空后该做的事情,
        if (tUser.getFlag()!=0){

            //生成一个uuid
            String uuid = UUID.randomUUID().toString();
            //创建一个token常量和uuid拼接作为redis的键
            String userkey = StringUtils.splicingString(uuid);
            System.out.println("用户登陆产生的redis键:"+userkey);
            //将userkey存入,需要序列化
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            redisTemplate.opsForValue().set(userkey,tUser);
            //设置过期时间
            redisTemplate.expire(userkey,30, TimeUnit.SECONDS);
            //返回cookie
            Cookie cookie = new Cookie(Cookiekeys.COOKIE_USER_LOGIN,uuid);
            cookie.setPath("/");
            //cookie.setDomain("qf.com");
            cookie.setHttpOnly(true);
            response.addCookie(cookie);

            return "redirect:http://localhost:8092/list";
        }
        return  "login";
    }
    /**
     * 验证客户端是否登陆
     * @param uuid 前端传入的uuid
     * @return
     */
    @RequestMapping("checkIsLogin")
    @ResponseBody
    public ReslutBean checkIsLogin(@CookieValue(value = Cookiekeys.COOKIE_USER_LOGIN,required = false)String uuid){

        System.out.println("验证客户端传入的uuid:"+uuid);
        ReslutBean reslutBean = userService.checkIsLogin(uuid);
        return reslutBean;

    }




    /**
     * 注销用户
     * @param uuid
     * @param response
     * @return
     */
    @RequestMapping("logout")
    public String logout(@CookieValue(name = Cookiekeys.COOKIE_USER_LOGIN,required = false)String uuid,
                             HttpServletResponse response){

        //前端传入的组织键 去删除
        userService.Logout(uuid);

        Cookie cookie = new Cookie(Cookiekeys.COOKIE_USER_LOGIN, "");
        response.addCookie(cookie);
        cookie.setMaxAge(0);
        return "redirect:http://localhost:8091/user/toLogin";
    }
}
