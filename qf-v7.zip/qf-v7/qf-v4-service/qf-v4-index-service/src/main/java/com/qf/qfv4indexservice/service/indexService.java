package com.qf.qfv4indexservice.service;


import com.alibaba.dubbo.config.annotation.Service;
import com.qf.base.BaseServiceImpl;
import com.qf.base.IBaseDao;
import com.qf.entity.TProductType;
import com.qf.mapper.TProductTypeMapper;
import com.qf.v4.api.IProductTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
@Service
public class indexService extends BaseServiceImpl<TProductType> implements IProductTypeService {

    @Autowired
    private TProductTypeMapper mapper;


    @Override
    public IBaseDao<TProductType> getBaseDao() {

        return mapper;
    }


    @Override
    public List<TProductType> List() {

        return mapper.selectList();
    }
}
