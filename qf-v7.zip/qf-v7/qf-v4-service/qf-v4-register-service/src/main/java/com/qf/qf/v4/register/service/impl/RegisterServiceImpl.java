package com.qf.qf.v4.register.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.qf.constant.RabbitmqConstant;
import com.qf.constant.Rediskeys;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import com.qf.utils.StringUtils;
import com.qf.v4.api.IUserService;
import com.qf.v4.register.api.RegisterService;
import com.qf.v4.register.vo.RegistUserVO;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;


@Component
@Service
public class RegisterServiceImpl implements RegisterService {


    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private RedisTemplate redisTemplate;

    @Reference
    private IUserService userService;

    /**
     * 短信验证创建用户
     * @param user
     * @return
     */
    @Override
    public ReslutBean registerUser(RegistUserVO user) {
        System.out.println(user);
        if(user!=null) {
            //拼接key,获得redis中短信注册用户的验证码
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            String key = StringUtils.splicingString(Rediskeys.REGIST_USER_PHONE_PRE, user.getPhone());
            Object o = redisTemplate.opsForValue().get(key);
            System.out.println(o);
            System.out.println("拼接的key:"+key);
            String redis_code = String.valueOf((int) o);//强转
            System.out.println("传入的code"+redis_code);

            //判断是否相同,相同调用rabbitmq创建用户账
            if (user.getCode().equals(redis_code)) {

                redisTemplate.delete(key);

                TUser tUser = new TUser();
                tUser.setUsername(user.getPhone());
                tUser.setPassword(user.getPassword());
                tUser.setPhone(user.getPhone());
                System.out.println("需要操作的user对象:"+tUser);

                //int i = userService.smsAddUser(tUser);
                //rabbitmq解决一下,发送到sso创建用户账号
                rabbitTemplate.convertAndSend(RabbitmqConstant.SMS_CHECKING_REGISTER,RabbitmqConstant.SMS_CHECKING_KEY
                ,tUser);

                //System.out.println("受影响行数:"+i);

                return ReslutBean.success("验证码正确");
            }
        }
        return ReslutBean.error("验证码错误");
    }

}
