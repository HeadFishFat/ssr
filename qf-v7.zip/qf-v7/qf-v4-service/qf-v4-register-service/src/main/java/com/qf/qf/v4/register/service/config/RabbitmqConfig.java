package com.qf.qf.v4.register.service.config;


import com.qf.constant.RabbitmqConstant;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitmqConfig {

    //声明一个交换机
    @Bean
    public TopicExchange getTopicExchage(){

        return new TopicExchange(RabbitmqConstant.SMS_CHECKING_REGISTER);
    }

}
