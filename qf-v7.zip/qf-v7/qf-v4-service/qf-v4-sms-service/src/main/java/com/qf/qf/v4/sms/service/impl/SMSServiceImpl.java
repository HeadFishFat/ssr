package com.qf.qf.v4.sms.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.qf.constant.Rediskeys;
import com.qf.dto.ReslutBean;
import com.qf.qf.v4.sms.service.util.SMSUtil;
import com.qf.utils.StringUtils;
import com.qf.v4.sms.api.ISMSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
@Service
public class SMSServiceImpl implements ISMSService {


    @Value("${sms.account}")
    private String account;
    @Value("${sms.password}")
    private String password;
    @Value("${sms.veryCode}")
    private String veryCode;
    @Value("${sms.http_url}")
    private String http_url;
    @Value("${sms.tplid}")
    private String tplid;

    //注入redis模板
    @Autowired
    private RedisTemplate redisTemplate;


    public ReslutBean sendSMS(String phone){

        SMSUtil.account = account;
        SMSUtil.password = password;
        SMSUtil.veryCode = veryCode;
        SMSUtil.http_url = http_url;

        //随机四位验证码
        int code_i = (int)((Math.random()*9+1)*10000);
        String code = "@1@="+code_i;
        String result = SMSUtil.sendTplSms(phone, tplid, code);


        System.out.println(result);

        //获得三方短信商家返回状态码
        int start =  result.lastIndexOf("<status>")+8;
        int end = result.lastIndexOf("</status>");

        //判断是否发送成功,0为成功,108为欠费
       String result_sub = result.substring(start,end);
       if (result_sub.equals("0")){
           //短信发送成功,将用户验证码组织redis键上传
           redisTemplate.setKeySerializer(new StringRedisSerializer());

           String key = StringUtils.splicingString(Rediskeys.REGIST_USER_PHONE_PRE, phone);

           //往redis服务器中存
           redisTemplate.opsForValue().set(key,code_i);
           //设置超时时间
           redisTemplate.expire(key,30, TimeUnit.MINUTES);

           return ReslutBean.success("短信发送成功");
       }
        return ReslutBean.error("短信发送失败");
    }

}
