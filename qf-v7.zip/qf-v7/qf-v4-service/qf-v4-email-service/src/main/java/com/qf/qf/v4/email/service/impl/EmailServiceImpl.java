package com.qf.qf.v4.email.service.impl;


import api.IEmailService;
import com.alibaba.dubbo.config.annotation.Service;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;


@Component
@Service
public class EmailServiceImpl implements IEmailService {

    //导入邮件模板
    @Autowired
    private JavaMailSender sender;

    @Autowired
    private TemplateEngine templateEngine;


    public ReslutBean sendMail(TUser user){

        System.out.println("id:"+user.getId());

        try {
            MimeMessage message = sender.createMimeMessage();

            MimeMessageHelper mailMessage = new MimeMessageHelper(message,true);

            //数据
            Context context = new Context();
            context.setVariable("username",user.getEmail());
            context.setVariable("userId",user.getId());
            //模板+数据==字符串
            String info = templateEngine.process("mailtl", context);
            mailMessage.setText(info,true);


            mailMessage.setFrom("x724955745@163.com");
            mailMessage.setTo(user.getEmail());
            mailMessage.setSubject("欢迎来到我的商场！请完成注册！");

            sender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
            return ReslutBean.error("发送失败");
        }

        return ReslutBean.success("发送成功");
    }



}
