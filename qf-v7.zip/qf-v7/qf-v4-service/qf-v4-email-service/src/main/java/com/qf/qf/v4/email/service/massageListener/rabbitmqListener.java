package com.qf.qf.v4.email.service.massageListener;


import api.IEmailService;
import com.qf.constant.RabbitmqConstant;
import com.qf.entity.TUser;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class rabbitmqListener {

    @Autowired
    private IEmailService emailService;

    @RabbitListener(queues = RabbitmqConstant.EMAIL_CHECKING_QUEUE)
    public void process(TUser user){

        emailService.sendMail(user);

    }
}
