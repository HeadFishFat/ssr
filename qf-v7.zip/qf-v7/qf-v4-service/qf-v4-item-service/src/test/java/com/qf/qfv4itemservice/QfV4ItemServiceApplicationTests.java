package com.qf.qfv4itemservice;

import com.qf.entity.TProduct;
import com.qf.v4.item.api.ItemService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QfV4ItemServiceApplicationTests {

    @Autowired
    private ItemService itemService;

    @Test
    public void contextLoads() {

        TProduct tProduct = new TProduct();

        tProduct.setId(1L);
        tProduct.setName("测试1号");
        tProduct.setSalePrice(1000L);
        tProduct.setImage("1.jpg");
        tProduct.setPrice(999L);

        itemService.initDetail(tProduct);



    }

}
