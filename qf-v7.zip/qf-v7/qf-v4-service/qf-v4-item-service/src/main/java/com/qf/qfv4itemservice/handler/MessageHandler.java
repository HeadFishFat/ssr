package com.qf.qfv4itemservice.handler;

import com.qf.constant.RabbitmqConstant;
import com.qf.entity.TProduct;
import com.qf.v4.item.api.ItemService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MessageHandler {

    @Autowired
    private ItemService itemService;

    @RabbitListener(queues = RabbitmqConstant.ITEM_ADD_UPDATE_QUEUE)
    public void process(TProduct tProduct){

        itemService.initDetail(tProduct);

    }


}
