package com.qf.qfv4itemservice.impl;


import com.alibaba.dubbo.config.annotation.Service;
import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;
import com.qf.v4.item.api.ItemService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.*;

@Component
@Service
public class ItemServiceImpl implements ItemService {

    /**/

    @Autowired
    private Configuration configuration;

    @Value("${itemServer.path}")
    private String itemServerPath;


    /**
     * 生成静态页
     * @param tProduct
     * @return
     */
    @Override
    public ReslutBean initDetail(TProduct tProduct) {

        System.out.println("id=="+tProduct.getId());

        try {
            //创建模板对象
            Template template = configuration.getTemplate("SD_info.ftl");
            //为模板添加数据
            HashMap<String,Object> map = new HashMap<>();

            map.put("product",tProduct);

            FileWriter out = new FileWriter(itemServerPath + tProduct.getId() + ".html");

            template.process(map,out);

        } catch (IOException | TemplateException e) {
            e.printStackTrace();
            return  ReslutBean.error("error");
        }

        return ReslutBean.success("success");
    }

    /**
     * 批量生成静态页(多线程)
     * @param tProducts 传入的商品集合
     * @return
     */
    @Override
    public ReslutBean batchGenerateDetail(List<TProduct> tProducts) {
        //获得本电脑的最大核心数
        int processors = Runtime.getRuntime().availableProcessors();

        ThreadPoolExecutor poolExecutor = new ThreadPoolExecutor(processors,
                processors * 2, 20L, TimeUnit.MINUTES,
                new LinkedBlockingDeque<Runnable>(1000));

        List<Future<Boolean>> futures = new ArrayList<>();
        for (TProduct product : tProducts) {
            Future<Boolean> submit = poolExecutor.submit(new GenerateDetailCallable(product));
            futures.add(submit);

        }
        return ReslutBean.success("批量生成成功");
    }

        class  GenerateDetailCallable implements Callable<Boolean> {

            private TProduct tProduct;

            public GenerateDetailCallable(TProduct tProduct) {
                this.tProduct = tProduct;
            }

            @Override
            public Boolean call() throws Exception {

                Template template = configuration.getTemplate("introduction.ftl");

                HashMap<String, Object> data = new HashMap<>();

                data.put("product",tProduct);

                FileWriter out = new FileWriter(itemServerPath+tProduct.getId()+".html");

                template.process(data,out);

                return true;

        }
    }
}
