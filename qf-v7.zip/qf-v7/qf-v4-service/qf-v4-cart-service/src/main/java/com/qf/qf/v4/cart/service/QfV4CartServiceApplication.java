package com.qf.qf.v4.cart.service;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@MapperScan("com.qf.mapper")
@EnableDubbo
@SpringBootApplication
public class QfV4CartServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(QfV4CartServiceApplication.class, args);
    }

}
