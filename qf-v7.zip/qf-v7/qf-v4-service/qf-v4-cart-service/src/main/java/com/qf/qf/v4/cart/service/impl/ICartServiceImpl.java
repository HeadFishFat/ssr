package com.qf.qf.v4.cart.service.impl;


import com.alibaba.dubbo.config.annotation.Service;
import com.qf.constant.Rediskeys;
import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;
import com.qf.mapper.TProductMapper;
import com.qf.utils.StringUtils;
import com.qf.v4.cart.api.ICartService;
import com.qf.v4.cart.dto.CartItemDTO;
import com.qf.v4.cart.vo.CartItemVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Component
@Service
public class ICartServiceImpl implements ICartService {

    //注入radis模板
    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private TProductMapper tProductMapper;

    @Override
    public ReslutBean addProductToCart(Long productId, int count, String key) {

        //1.redis中没有该用户对应的集合
        //序列化
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        //组织键
        String ukey = StringUtils.splicingString(Rediskeys.CART_USER_PRE, key);
        //去redis查询
        Object o = redisTemplate.opsForValue().get(ukey);
        if (o==null)
        {
            //表示redis中没有该用户的购物车
            CartItemVO cartItemVO = new CartItemVO();
            cartItemVO.setProductId(productId);
            cartItemVO.setCount(count);
            cartItemVO.setUpdate_time(new Date());

            ArrayList<CartItemVO> list = new ArrayList<>();
            list.add(cartItemVO);

            //将集合存入redis中设置有效期为30天
            opsRedisCart(ukey,list);
            return ReslutBean.success(list,"存入购物车成功");
        }

        //第二种,用户集合存在,商品也存在
        List<CartItemVO> list = (List<CartItemVO>) o;
        //将用户list中的商品数量对应叠加并重新设置修改时间
        for (CartItemVO cartItemVO : list) {
            if (cartItemVO.getProductId().longValue()==productId.longValue()){
                cartItemVO.setCount(count);
                cartItemVO.setUpdate_time(new Date());
                //重新设置过期时间
                opsRedisCart(ukey,list);
                return ReslutBean.success(list,"存入购物车成功");
            }
        }

        //第三种:用户集合存在没有商品
        CartItemVO product = new CartItemVO();
        product.setProductId(productId);
        product.setCount(count);
        product.setUpdate_time(new Date());
        list.add(product);
        //将集合存入到redis中，并超时时间为30天
        opsRedisCart(ukey,list);
        return ReslutBean.success(list,"添加购物车成功");
    }

    /**
     * 查看购物车
     * @param key
     * @return
     */
    @Override
    public ReslutBean getCart(String key) {

        //拼接redis的key,然后去redis中查询该购物车
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        String ukey = StringUtils.splicingString(Rediskeys.CART_USER_PRE, key);
        Object o = redisTemplate.opsForValue().get(ukey);

        if (o==null) {
            return ReslutBean.error("当前用户没有购物车");
        }

            //有商品
            List<CartItemVO>  cartItemVOS =  (List<CartItemVO>) o ;
            ArrayList<CartItemDTO> cartItemDTOs = new ArrayList<>(cartItemVOS.size());
            //遍历
            for (CartItemVO cartItemVO : cartItemVOS) {
                //创建一个数据传输类型
                CartItemDTO cartItemDTO = new CartItemDTO();
                cartItemDTO.setCount(cartItemVO.getCount());
                cartItemDTO.setUpdate_time(cartItemVO.getUpdate_time());

                TProduct tProduct =null;

                //查询缓存商品可能为空,
                //拼接redis键
                String productKey = StringUtils.splicingString(Rediskeys.PRODUCT_PRE,
                        cartItemVO.getProductId().toString());

                        //根据键查询redis
                Object o1 = redisTemplate.opsForValue().get(productKey);
                //判断是否为空,
                if (o1!=null){
                    tProduct = (TProduct) o1;
                }else {
                    //为空去数据库查询
                    tProduct = tProductMapper.selectByPrimaryKey(cartItemVO.getProductId());
                    //存入redis
                    redisTemplate.opsForValue().set(productKey,tProduct);
                    //重新设置过期时间
                }
                redisTemplate.expire(productKey,30,TimeUnit.DAYS);

                cartItemDTO.setProduct(tProduct);
                cartItemDTOs.add(cartItemDTO);
            }
            //返回带着所有商品对象的集合
            return ReslutBean.success(cartItemDTOs,"");

    }

    /**
     * 更新购物车
     * @param key 前端传入的key
     * @param productId 需要更新商品的id
     * @param count 需要更新商品的数量
     * @return
     */
    @Override
    public ReslutBean updateCarat(String key, Long productId, int count) {

        redisTemplate.setKeySerializer(new StringRedisSerializer());

        //组织键
        String ukey = StringUtils.splicingString(Rediskeys.CART_USER_PRE, key);
        Object o = redisTemplate.opsForValue().get(ukey);
        if (o==null){
            return ReslutBean.error("该用户没有购物车");
        }
        //不为空则遍历更新
        List<CartItemVO> list = (List<CartItemVO>) o;
        //遍历用户集合
        for (CartItemVO cartItemVO : list) {
            if (cartItemVO.getProductId().longValue()==productId.longValue()){
                cartItemVO.setCount(count);
                cartItemVO.setUpdate_time(new Date());
                //设置排序跟过期时间
                opsRedisCart(ukey,list);
                return ReslutBean.success(list,"更新购物车成功");
            }
        }
        return ReslutBean.error("更新购物车失败");
    }

    /**
     * 根据id删除商品
     * @param key
     * @param productId
     * @return
     */
    @Override
    public ReslutBean deleteCartById(String key, Long productId) {

        redisTemplate.setKeySerializer(new StringRedisSerializer());
        //组织键
        String ukey = StringUtils.splicingString(Rediskeys.CART_USER_PRE, key);
        Object o = redisTemplate.opsForValue().get(ukey);

        if (o==null){
            return ReslutBean.error("用户没有购物车");
        }
        List<CartItemVO> list = (List<CartItemVO>) o;
        //使用迭代器来删除
        Iterator<CartItemVO> iterator = list.iterator();
        while (iterator.hasNext()){
            CartItemVO next = iterator.next();
            if (next.getProductId().longValue()==productId.longValue()){
                iterator.remove();
                //把集合更新回redis中
                redisTemplate.opsForValue().set(ukey,list);
                //重新设置时间
                redisTemplate.expire(ukey,30,TimeUnit.DAYS);
                return ReslutBean.success("删除商品成功");
            }
        }
        return ReslutBean.error("删除商品失败");
    }


    /**
     * 抽取设置过期时间,排序方法
     * @param key
     * @param list
     */
    public void opsRedisCart(String key, List<CartItemVO> list){

        Collections.sort(list, new Comparator<CartItemVO>() {
            @Override
            public int compare(CartItemVO o1, CartItemVO o2) {
                //排序
                return (int)(o2.getUpdate_time().getTime()-o1.getUpdate_time().getTime());
            }
        });

        //设置过期方法
        redisTemplate.opsForValue().set(key,list);
        redisTemplate.expire(key,30, TimeUnit.DAYS);

    }
}
