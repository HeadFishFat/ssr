package com.qf.qfv4ssoservice.serviceimpl;


import com.alibaba.dubbo.config.annotation.Service;
import com.qf.base.BaseServiceImpl;
import com.qf.base.IBaseDao;
import com.qf.constant.RabbitmqConstant;
import com.qf.dto.ReslutBean;
import com.qf.entity.TUser;
import com.qf.mapper.TUserMapper;
import com.qf.utils.StringUtils;
import com.qf.v4.api.IUserService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
@Service
public class UserServiceImpl extends BaseServiceImpl<TUser> implements IUserService {


    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private TUserMapper userMapper;

    @Autowired
    private BCryptPasswordEncoder encoder;

    @Autowired
    private RedisTemplate redisTemplate;


    @Override
    public IBaseDao<TUser> getBaseDao() {
        return userMapper;
    }


    @Override
    public TUser Login(TUser user) {

        //判断传入的user是否未空
        if (user != null) {
            //不为空去数据库查询
            TUser user1 = userMapper.selectByUsername(user.getUsername());
            System.out.println(user1);
            //判断返回user对象是否为空

            //加密
            boolean matches = encoder.matches(user.getPassword(), user1.getPassword());
            System.out.println(matches);
            if (matches) {
                return user1;
            }
        }
        TUser tUser = new TUser();
        tUser.setFlag(0);
        return tUser;
    }


    /**
     * 验证当前用户是否登陆
     *
     * @param uuid
     * @return
     */
    @Override
    public ReslutBean checkIsLogin(String uuid) {
        //传入的uuid不为空的时候
        if (uuid != null) {

            //拼接成redis键
            String userkey = StringUtils.splicingString(uuid);
            System.out.println("传入uuid拼接成的键" + userkey);
            //序列化
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            TUser user = (TUser) redisTemplate.opsForValue().get(userkey);
            if (user != null) {
                //说明查询到了缓存,重置redis键过期时间
                redisTemplate.expire(userkey, 30, TimeUnit.SECONDS);
                return ReslutBean.success(user, "当前用户已经登陆");
            }
        }

        return ReslutBean.error("当前用户未登录");
    }

    @Override
    public ReslutBean Logout(String uuid) {

        if (uuid != null) {

            //拼接字符串
            String userkey = StringUtils.splicingString(uuid);
            //序列化
            redisTemplate.setKeySerializer(new StringRedisSerializer());
            redisTemplate.delete(userkey);

            return ReslutBean.success("用户已注销");

        }


        return ReslutBean.error("用户未登录");
    }

    @Override
    public Long save(TUser user) {

        if (user!=null){
            String password = encoder.encode(user.getPassword());
            user.setPassword(password);
        }
        userMapper.insertSelective(user);
        Long id = user.getId();
        return id;
    }

    /**
     * 邮箱验证添加未激活用户
     * @param user
     * @return
     */
    @Override
    public int addUser(TUser user) {

        System.out.println(user.getEmail());
        System.out.println(user.getPassword());

        //数据库用户名不能为空,将email设置为username
        user.setUsername(user.getEmail());
        System.out.println(user.getUsername());

        int id = userMapper.insertOnUser(user);
        //user.setId((id);
        //若返回user对象的flag等于0,调用发送邮件方法
        if (id!=0){

            //使用rabbitmq添加user到交换机
            rabbitTemplate.convertAndSend(RabbitmqConstant.EMAIL_CHECKING_REGISTER,
                    RabbitmqConstant.EMAIL_CHECKING_KEY, user);

            /*emailService.sendMail(user);*/
            System.out.println("数据库是否创建未激活用户:"+user);
        }
        return id;
    }


    /**
     * 激活用户flag
     * @param id
     * @return
     */
    @Override
    public ReslutBean updateUserFlag(Long id) {

        int i = userMapper.updateByUserId(id);
        if (i != 0){
            return ReslutBean.success("注册成功,请返回登陆页面登陆");
        }

        return ReslutBean.error("注册失败");
    }


    /**
     * 短信注册账户
     * @param tUser
     */
    @Override
    public int smsAddUser(TUser tUser) {

        System.out.println("传入的user对象"+tUser);

        int i = userMapper.smsAddUser(tUser);

        return i;
    }


    @Override
    public List<TUser> List() {
        return null;
    }
}
