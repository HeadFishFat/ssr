package com.qf.qfv4ssoservice.config;


import com.qf.constant.RabbitmqConstant;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitmqConfig {

    //声明一个交换机
    @Bean
    public TopicExchange getTopicExchage(){

        return new TopicExchange(RabbitmqConstant.EMAIL_CHECKING_REGISTER);
    }

    @Bean
    public TopicExchange getSmsTopicExchage(){

        return new TopicExchange(RabbitmqConstant.SMS_CHECKING_REGISTER);
    }

    @Bean
    public Queue getQueue(){
        return new Queue(RabbitmqConstant.SMS_CHECKING_QUEUE);
    }

    @Bean
    public Binding getBind(Queue getQueue,TopicExchange getSmsTopicExchage){
        return BindingBuilder.bind(getQueue).to(getSmsTopicExchage).with(RabbitmqConstant.SMS_CHECKING_KEY);
    }
}
