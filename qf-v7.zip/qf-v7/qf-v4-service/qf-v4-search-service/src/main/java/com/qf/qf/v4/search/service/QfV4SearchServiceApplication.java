package com.qf.qf.v4.search.service;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.qf.qf.v4.search.service.mapper")
@EnableDubbo
@SpringBootApplication
public class QfV4SearchServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(QfV4SearchServiceApplication.class, args);
    }

}
