package com.qf.qf.v4.search.service.handler;

import com.qf.constant.RabbitmqConstant;
import com.qf.v4.api.ISearchService;
import com.qf.v4.api.entity.TProductResult;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MessageHandler {

    @Autowired
    private ISearchService searchService;

    /*
    监听消息队列，当队列中有消息，则消费消息，通过调用searchService.addItemToSolr来消费消息
     */
    @RabbitListener(queues = RabbitmqConstant.PRODUCT_ADD_UPDATE_QUEUE)
    public void process(TProductResult tProductResult){
        searchService.initToSolr(tProductResult);

    }
}
