package com.qf.qf.v4.search.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.qf.dto.ReslutBean;
import com.qf.qf.v4.search.service.mapper.TProductResultMapper;
import com.qf.v4.api.ISearchService;
import com.qf.v4.api.entity.TProductResult;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Component
@Service
public class SearchService implements ISearchService {

    @Autowired
    private TProductResultMapper mapper;

    @Autowired
    private SolrClient solrClient;


    public ReslutBean initToSolr(TProductResult tProductResult){

        SolrInputDocument fields = new SolrInputDocument();
        fields.addField("id",tProductResult.getId());
        fields.addField("t_name",tProductResult.gettName());
        fields.addField("t_price",tProductResult.gettPrice().intValue());
        fields.addField("t_product_desc",tProductResult.getProductDesc());
        fields.addField("t_image",tProductResult.gettImage());
        fields.addField("t_sale_point",tProductResult.getSalePoint());

        try {
            solrClient.add(fields);
            solrClient.commit();
        } catch (SolrServerException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ReslutBean.success("success");
    }


    /**
     * 添加数据库数据到索引库
     * @return
     */
    @Override
    public ReslutBean infoSolrData() {
        //从数据库中获得所有数据
        List<TProductResult> tProductResults = mapper.selectList();
        System.out.println("获得DB中的数据=="+tProductResults);
        //添加到solr中
        for (TProductResult tProductResult : tProductResults) {
            SolrInputDocument document = new SolrInputDocument();
            document.addField("id",tProductResult.getId());
            document.addField("t_name",tProductResult.gettName());
            document.addField("t_price",tProductResult.gettPrice().intValue());
            document.addField("t_product_desc",tProductResult.getProductDesc());
            document.addField("t_image",tProductResult.gettImage());
            document.addField("t_sale_point",tProductResult.getSalePoint());

            try {
                solrClient.add(document);
                solrClient.commit();

            } catch (Exception e) {
                e.printStackTrace();
                return ReslutBean.error("添加到索引库失败");
            }

        }
        return ReslutBean.success("添加到索引库成功");
    }

    /**
     * 根据搜索关键词查询索引库
     * @param keywords 关键词
     * @return
     */
    @Override
    public ReslutBean<List<TProductResult>> selectByKeywords(String keywords) {

        //创建查询条件
        SolrQuery entries = new SolrQuery();

        //设置查询的行数
        entries.setStart(0);
        entries.setRows(50);

        //设置高亮
        entries.setHighlight(true);
        entries.setMoreLikeThisFields("t_name");
        entries.setHighlightSimplePre("<span style='color:red'>");
        entries.setHighlightSimplePost("</span>");

        //设置查询复制域
        entries.set("df","t_keywords");
        //设置查询关键词
        entries.setQuery(keywords);


        ArrayList<TProductResult> products = null;
        try {
            QueryResponse response = solrClient.query(entries);
            SolrDocumentList documents = response.getResults();

            Map<String, Map<String, List<String>>> highlighting  = response.getHighlighting();

            products = new ArrayList<>();

            for (SolrDocument document : documents) {
                TProductResult product = new TProductResult();
                product.setId(Long.parseLong((String)document.getFieldValue("id")));
                product.settName((String)document.getFieldValue("t_name"));
                product.settImage((String)document.getFieldValue("t_image"));
                product.setSalePoint((String)document.getFieldValue("t_sale_point"));
                product.settPrice(new BigDecimal((Float)document.getFieldValue("t_price")));
                product.setProductDesc((String)document.getFieldValue("t_product_desc"));

                Map<String, List<String>> map = highlighting.get(document.getFieldValue("id"));
                List<String> tnameList = map.get("t_name");
                if(tnameList!=null&&tnameList.size()>0){
                    String tname_data = tnameList.get(0);
                    product.settName(tname_data);
                }
                products.add(product);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ReslutBean.error("服务器忙,请刷新");
        }

        ReslutBean<List<TProductResult>> reslutBean = new ReslutBean<>();
        reslutBean.setErrno(0);
        reslutBean.setData(products);
        reslutBean.setMessage("查询成功");

        System.out.println("获得的数据=="+reslutBean);

        return reslutBean;

       /* SolrQuery query = new SolrQuery();

        query.set("df","t_keywords");

        query.setStart(0);
        query.setRows(12);

        query.setQuery(keywords);

        //设置高亮

        query.setHighlight(true);
        query.addHighlightField("t_name");
        query.setHighlightSimplePre("<span style='color:red'>");
        query.setHighlightSimplePost("</span>");

        List<TProductResult> products = null;
        try {
            QueryResponse response = solrClient.query(query);
            //获得所有的记录的集合
            SolrDocumentList documents = response.getResults();
            //获得所有记录的高亮数据的集合
            Map<String, Map<String, List<String>>> highlighting = response.getHighlighting();

            products = new ArrayList<>();
            for (SolrDocument document : documents) {

                TProductResult product = new TProductResult();
                product.setId(Long.parseLong((String)document.getFieldValue("id")));
                product.settName((String)document.getFieldValue("t_name"));
                product.settImage((String)document.getFieldValue("t_image"));
                product.setSalePoint((String)document.getFieldValue("t_sale_point"));
                product.settPrice(new BigDecimal((Float)document.getFieldValue("t_price")));
                product.setProductDesc((String)document.getFieldValue("t_product_desc"));

                //从highlighting这个map里把高亮的数据拿到，把product的name替换掉
                Map<String, List<String>> map = highlighting.get(document.getFieldValue("id"));
                List<String> tnameList = map.get("t_name");
                if(tnameList!=null&&tnameList.size()>0){
                    String tname_data = tnameList.get(0);
                    product.settName(tname_data);
                }
                products.add(product);


            }



        } catch (Exception e) {
            e.printStackTrace();
            return ReslutBean.error("搜索服务器繁忙，请稍后重试");
        }
        ReslutBean<List<TProductResult>> resultBean = new ReslutBean<>();
        resultBean.setErrno(0);
        resultBean.setData(products);
        resultBean.setMessage("查询成功");


        return resultBean;*/
    }
}
