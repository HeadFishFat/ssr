package com.qf.qf.v4.search.service.mapper;

import com.qf.entity.TProduct;
import com.qf.v4.api.entity.TProductResult;

import java.util.List;

public interface TProductResultMapper {
    //将数据中的所有数据添加入solr索引库中
    List<TProductResult>  selectList();

    //添加单条数据到索引库
    TProduct initToSolr(TProduct tProduct);

}
