package com.qf.qf.v4.search.service;

import com.qf.qf.v4.search.service.mapper.TProductResultMapper;
import com.qf.v4.api.entity.TProductResult;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QfV4SearchServiceApplicationTests {

    @Autowired
    private TProductResultMapper mapper;

    @Autowired
    private SolrClient solrClient;

    @Test
    public void contextLoads() {
    }

    /**
     * 获得数据库中所有的数据
     */
    @Test
    public void testQueryList(){

        List<TProductResult> tProductResults = mapper.selectList();
        System.out.println(tProductResults);

    }

    /**
     * 往solr添加一条数据
     */
    @Test
    public void testAddProduct(){
        //创建存入对象
        TProductResult productResult = new TProductResult();
        productResult.setId(1004L);
        productResult.settName("吉娃娃");
        productResult.settPrice(new BigDecimal(5555));
        productResult.setProductDesc("就是好玩");
        productResult.settImage("pic/img");
        productResult.setSalePoint("挺贵的");


        //将传输对象存入solrClient中
        SolrInputDocument fields = new SolrInputDocument();
        fields.addField("id",productResult.getId());
        fields.addField("t_name",productResult.gettName());
        fields.addField("t_price",productResult.gettPrice().intValue());
        fields.addField("t_product_desc",productResult.getProductDesc());
        fields.addField("t_image",productResult.gettImage());
        fields.addField("t_sale_point",productResult.getSalePoint());

        try {
            solrClient.add(fields);
            solrClient.commit();
        } catch (SolrServerException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    /**
     * 根据id删除
     */
    @Test
    public void  testDelById(){

        try {
            solrClient.deleteById("1001");
            solrClient.commit();
        } catch (SolrServerException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    /**
     * 普通查询
     * @throws IOException
     * @throws SolrServerException
     */
    @Test
    public void testQuery() throws IOException, SolrServerException {

        //将查询设置对象封装进solr的查询方法中
        SolrQuery query = new SolrQuery();


        //设置查询显示
        query.setStart(0);
        query.setRows(10);
        //设置复制域
        query.set("df","t_keywords");

        //设置查询关键词
        query.setQuery("类型");

        //将查询对象添加
        QueryResponse response = solrClient.query(query);
        //获得结果集
        SolrDocumentList documents = response.getResults();
        //创建一个集合来装
        ArrayList<TProductResult> products = new ArrayList<>();
        //遍历结果集
        for (SolrDocument document : documents) {
            TProductResult product = new TProductResult();
            product.setId(Long.parseLong((String)document.getFieldValue("id")));
            product.settName((String)document.getFieldValue("t_name"));
            product.settImage((String)document.getFieldValue("t_image"));
            product.setSalePoint((String)document.getFieldValue("t_sale_point"));
            //product.settPrice(new BigDecimal((Float)document.getFieldValue("t_price")));
            product.setProductDesc((String)document.getFieldValue("t_product_desc"));
            products.add(product);
        }
        System.out.println(products);
    }


    /**
     * 查询关键字设置高亮
     */
    @Test
    public void testHFQuert() throws IOException, SolrServerException {

        SolrQuery entries = new SolrQuery();

        entries.setStart(0);
        entries.setRows(10);

        entries.setHighlight(true);
        entries.setMoreLikeThisFields("t_name");
        entries.setHighlightSimplePre("<span style='color:red'>");
        entries.setHighlightSimplePost("</span>");

        entries.set("df","t_keywords");

        entries.setQuery("吉娃娃");



        QueryResponse response = solrClient.query(entries);

        SolrDocumentList documents = response.getResults();

        Map<String, Map<String, List<String>>> highlighting  = response.getHighlighting();

        ArrayList<TProductResult> products = new ArrayList<>();

        for (SolrDocument document : documents) {
            TProductResult product = new TProductResult();
            product.setId(Long.parseLong((String)document.getFieldValue("id")));
            product.settName((String)document.getFieldValue("t_name"));
            product.settImage((String)document.getFieldValue("t_image"));
            product.setSalePoint((String)document.getFieldValue("t_sale_point"));
            product.settPrice(new BigDecimal((Float)document.getFieldValue("t_price")));
            product.setProductDesc((String)document.getFieldValue("t_product_desc"));

            //获得数据中高亮的部分
           /* Map<String, List<String>> map = highlighting.get(document.getFieldValue("id"));
            List<String> tnameList  = map.get("t_name");
            if (tnameList!=null&&tnameList .size()>0)
            {
                String s = tnameList.get(0);
                product.settName(s);
            }*/

            Map<String, List<String>> map = highlighting.get(document.getFieldValue("id"));
            List<String> tnameList = map.get("t_name");
            if(tnameList!=null&&tnameList.size()>0){
                String tname_data = tnameList.get(0);
                product.settName(tname_data);
            }

            products.add(product);

        }

        System.out.println(products);

    }
}
