package com.qf.v4.product.service.provider.config;


import com.qf.constant.RabbitmqConstant;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 声明一个交换机
 */
@Configuration
public class RabbitmqConfig {

    @Bean
    public TopicExchange getTopicExchange(){
        return new TopicExchange(RabbitmqConstant.PRODUCT_ADD_EXCHANGE);
    }
}
