package com.qf.v4.product.service.provider.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.config.annotation.Service;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qf.base.BaseServiceImpl;
import com.qf.base.IBaseDao;
import com.qf.constant.RabbitmqConstant;
import com.qf.dto.ReslutBean;
import com.qf.entity.TProduct;
import com.qf.entity.TProductDesc;
import com.qf.entity.TProductDetails;
import com.qf.mapper.TProductDescMapper;
import com.qf.mapper.TProductDetailsMapper;
import com.qf.mapper.TProductMapper;
import com.qf.product.api.dto.ProductDTo;
import com.qf.product.api.service.IProductService;
import com.qf.v4.api.ISearchService;
import com.qf.v4.api.entity.TProductResult;
import com.qf.v4.item.api.ItemService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@Service
public class ProductServiceImpl extends BaseServiceImpl<TProduct> implements IProductService {

    @Autowired
    private TProductMapper productMapper;

    @Autowired
    private TProductDescMapper productDescMapper;

    @Autowired
    private TProductDetailsMapper detailsMapper;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Reference
    private ISearchService searchService;

    @Reference
    private ItemService itemService;

    @Override
    public IBaseDao<TProduct> getBaseDao() {
        return productMapper;
    }


    /**
     * 获得所有商品信息
     * @return
     */
    @Override
    public List<TProduct> selectProducts() {
        return productMapper.selectProducts();
    }


    /**
     * 分页功能
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public PageInfo<TProduct> getPageInfo(int pageNum,int pageSize) {
        //开始启动分页功能
        PageHelper.startPage(pageNum, pageSize);
        //给分页插件提供数据
        List<TProduct> productList = List();
        //获取分页数据信息
        PageInfo<TProduct> tPageInfo = new PageInfo<>(productList, 5);

        return tPageInfo;
    }

    @Override
    public List<TProduct> List() {

        List<TProduct> list = productMapper.List();

        return list;
    }

    /**
     * 设置分页
     * @return
     */

    @Override
    public Long save(ProductDTo dto) {
        //将dto中的商品信息与商品详情分别存储到两张表内
        TProduct product = dto.getProduct();
        productMapper.insertSelective(product);
        //获得商品id
        Long id = product.getId();
        System.out.println("回显id" + id);
        //创建商品详情对象
        TProductDesc desc = new TProductDesc();
        //传入回显id
        desc.setPid(id);

        desc.setProductDesc(dto.getProductDesc());
        System.out.println("传入的详情-->" + desc);
        productDescMapper.insertSelective(desc);

        //添加详情属性
        TProductDetails d = dto.getDetails();
        TProductDetails details = new TProductDetails();
        details.setPid(id);
        details.setSpecs(d.getSpecs());
        details.setSection(d.getSection());
        details.setVoltage(d.getVoltage());
        details.setModel(d.getModel());


        detailsMapper.insertSelective(details);

        //添加商品到solr
        TProductResult productResult = new TProductResult();
        productResult.setId(id);
        productResult.settName(product.getName());
        productResult.settPrice(new BigDecimal(product.getPrice()));
        productResult.setSalePoint(product.getSalePoint());
        productResult.setProductDesc(dto.getProductDesc());
        productResult.settImage(product.getImage());
        //添加时候添加到solr索引库

        rabbitTemplate.convertAndSend(RabbitmqConstant.PRODUCT_ADD_EXCHANGE,
                RabbitmqConstant.SEARCH_ADD_ROUTING_KEY, productResult);

        //添加时候生成商品详情页
        /*ReslutBean reslutBean = itemService.initDetail(product);

        System.out.println(reslutBean.getMessage());*/

        rabbitTemplate.convertAndSend(RabbitmqConstant.PRODUCT_ADD_EXCHANGE,
                RabbitmqConstant.ITEM_ADD_ROUTING_KEY,
                product);

        return id;
    }

    @Override
    public Long updateById(ProductDTo dTo) {

        //先更新商品表,获得id
        Long id = dTo.getProduct().getId();
        productMapper.updateById(dTo.getProduct());

        //更新详情
        //添加详情属性
        TProductDetails d = dTo.getDetails();
        //根据回显id更新详情
        d.setPid(id);
        detailsMapper.updateById(d);
        return id;
    }

    @Override
    public ReslutBean selectById(Long id) {

        TProduct tProduct = productMapper.selectByPrimaryKey(id);

        return ReslutBean.success(tProduct,"ok");
    }
}
