package com.qf.utils;

import com.github.tobato.fastdfs.domain.StorePath;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


/**
 * 图片上传&富文本框生成图片路径工具类
 */
public class ImageUtils {


    /**
     * 复用型工具类
     * @param protocol 协议
     * @param filepath 文件路径
     * @param fileServer 文件服务器路径
     * @return
     */
    public static String getImagePath(String protocol,String fileServer,String filepath){
       return protocol+"://"+fileServer+"/"+filepath;
    }


    /**
     * 上传多张图片
     * @param imageServer
     * @param client
     * @param file
     * @return
     */
    public static String[] filePathArr(FastFileStorageClient client, String IMAGE_HTTP, MultipartFile[] file) {
        //获得后缀

        String[] strings = new String[file.length];

        for (int i = 0; i < file.length; i++) {
            String originalFilename = file[i].getOriginalFilename();
            String etc = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);

            //获得文件名
            String fullPath = "";
            try {
                StorePath storePath = client.uploadImageAndCrtThumbImage(file[i].getInputStream(),
                        file[i].getSize(), etc, null);
                //调用图片地址工具类生成地址
                fullPath = ImageUtils.getImagePath("http", IMAGE_HTTP, storePath.getFullPath());

                strings[i] = fullPath;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println(strings);
        return strings;
    }

    /**
     *  上传单张图片
     * @param client
     * @param IMAGE_HTTP
     * @param file
     * @return
     */
    public static String filePath(FastFileStorageClient client, String IMAGE_HTTP, MultipartFile file){
        String originalFilename = file.getOriginalFilename();
        String etc = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);

        //获得文件名
        String fullPath = "";
        try {
            StorePath storePath = client.uploadImageAndCrtThumbImage(file.getInputStream(),
                                                                     file.getSize(), etc, null);

            //调用图片地址工具类生成地址
            fullPath = ImageUtils.getImagePath("http",IMAGE_HTTP,storePath.getFullPath());

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(fullPath);
        return fullPath;
    }
}
