package com.qf.constant;


/**
 * 创建redis拼接的key
 */
public interface Rediskeys {

     //单点登陆
     String USER_LOGIN_TOKEN = "user:token:";


     //邮箱验证
     String EMAIL_REGISTER_TOKEN = "email:token";

     //短信验证
     String REGIST_USER_PHONE_PRE = "regist:user:phone:";

     //购物车
     String CART_USER_PRE = "cart_user_pre";

     String PRODUCT_PRE = "product:";
}
