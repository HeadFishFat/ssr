package com.qf.base;

import com.github.pagehelper.PageInfo;

import java.util.List;

public abstract class BaseServiceImpl<T> implements IBaseService<T> {

    //必须提供一个Dao
    public abstract IBaseDao<T> getBaseDao();


    public int deleteByPrimaryKey(Long id) {
        return getBaseDao().deleteByPrimaryKey(id);
    }

    public int insert(T record) {
        return getBaseDao().insert(record);
    }

    public int insertSelective(T record) {
        return getBaseDao().insertSelective(record);
    }

    public T selectByPrimaryKey(Long id) {
        return getBaseDao().selectByPrimaryKey(id);
    }

    public Long updateByPrimaryKeySelective(T record) {
        return getBaseDao().updateByPrimaryKeySelective(record);
    }

    public int updateByPrimaryKey(T record) {
        return getBaseDao().updateByPrimaryKey(record);
    }

    //获取数据库中所有记录集合
    public List<T> List() {
        return getBaseDao().List();
    }

    public PageInfo<T> getPageInfo(int pageNum, int pageSize) {

        return getBaseDao().getPageInfo(pageNum,pageSize);
    }
}
