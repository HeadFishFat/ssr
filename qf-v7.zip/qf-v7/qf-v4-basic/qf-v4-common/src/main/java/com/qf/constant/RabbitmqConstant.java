package com.qf.constant;


/**
 * 交换机&队列
 */
public interface RabbitmqConstant {


    //商品添加交换机
    String PRODUCT_ADD_EXCHANGE = "product_add_exchange";

    //商品添加上传solr路由key
    String SEARCH_ADD_ROUTING_KEY = "search_add_routing_key";

    //商品添加上传solr队列
    String PRODUCT_ADD_UPDATE_QUEUE = "product_add_update_queue";

    /*================================================================*/

    //商品添加生成静态队列
    String ITEM_ADD_UPDATE_QUEUE = "item_add_update_queue";

    //商品添加生成静态路由key
    String ITEM_ADD_ROUTING_KEY = "item_add_routing_key";

    /*=================================================================*/


    //邮箱验证交换机
    String EMAIL_CHECKING_REGISTER = "email_checking_register";

    //邮箱验证队列
    String EMAIL_CHECKING_QUEUE = "email_checking_queue";

    //邮箱验证key
    String EMAIL_CHECKING_KEY = "email_checking_key";

    /*=================================================================*/

    //短信验证交换机
    String SMS_CHECKING_REGISTER = "sms_checking_register";

    //短信验证队列
    String SMS_CHECKING_QUEUE  = "sms_checking_queue";

    //短信验证路由key
    String SMS_CHECKING_KEY  = "sms_checking_key";

}
