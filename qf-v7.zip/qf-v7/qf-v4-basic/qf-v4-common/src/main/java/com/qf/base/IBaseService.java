package com.qf.base;

import com.github.pagehelper.PageInfo;

import java.util.List;

public interface IBaseService<T> {

    int deleteByPrimaryKey(Long id);

    int insert(T record);

    int insertSelective(T record);

    T selectByPrimaryKey(Long id);

    Long updateByPrimaryKeySelective(T record);

    int updateByPrimaryKey(T record);

    List<T> List();

    PageInfo<T> getPageInfo(int pageNum, int pageSize);
}
