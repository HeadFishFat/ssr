package com.qf.constant;

public interface Cookiekeys {

     //单点登陆
     String COOKIE_USER_LOGIN = "user_login";

     //邮箱验证
     String COOKIE_EMAIL_REGISTER = "email_register";

     //购物车
     String USER_CART = "user_cart";
}
