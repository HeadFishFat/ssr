package com.qf.utils;


import com.qf.constant.Rediskeys;

/**
 * StringBuilder拼接redis键工具类
 */
public class StringUtils {

    public static String splicingString(String uuid){

        //登陆生成的redis键
        return new StringBuilder().append(Rediskeys.USER_LOGIN_TOKEN).append(uuid).toString();

    }

    public static String splicingString(String key,String uuid){

        //登陆生成的redis键
        return new StringBuilder().append(key).append(uuid).toString();

    }
}
