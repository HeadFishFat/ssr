package com.qf.dto;

import java.io.Serializable;


/**
 * 数据传输实体类
 *
 * @param <T>
 */
public class ReslutBean<T> implements Serializable {

    private static ReslutBean reslutBean = new ReslutBean();


    private Integer errno;
    private T data;
    private String message;

    @Override
    public String toString() {
        return "ReslutBean{" +
                "errno=" + errno +
                ", data=" + data +
                ", message='" + message + '\'' +
                '}';
    }

    public static ReslutBean error(Object data,String message){

        reslutBean.setData(data);
        reslutBean.setErrno(1);
        reslutBean.setMessage(message);

        return reslutBean;
    }

    public static ReslutBean error(){

        reslutBean.setData(null);
        reslutBean.setErrno(1);
        reslutBean.setMessage(null);

        return reslutBean;
    }

    public static ReslutBean error(String message){

        reslutBean.setData(null);
        reslutBean.setErrno(1);
        reslutBean.setMessage(message);

        return reslutBean;
    }

    public static ReslutBean success(){

        reslutBean.setData(null);
        reslutBean.setErrno(0);
        reslutBean.setMessage(null);

        return reslutBean;
    }

    public static ReslutBean success(String message){

        reslutBean.setData(null);
        reslutBean.setErrno(0);
        reslutBean.setMessage(message);

        return reslutBean;
    }

    public static ReslutBean success(Object data,String message){

        reslutBean.setData(data);
        reslutBean.setErrno(0);
        reslutBean.setMessage(message);

        return reslutBean;
    }

    public Integer getErrno() {
        return errno;
    }

    public void setErrno(Integer errno) {
        this.errno = errno;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ReslutBean(Integer errno, T data, String message) {
        this.errno = errno;
        this.data = data;
        this.message = message;
    }

    public ReslutBean() {
    }
}
