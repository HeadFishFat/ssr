package com.qf.mapper;

import com.qf.base.IBaseDao;
import com.qf.entity.TProductDesc;

public interface TProductDescMapper extends IBaseDao<TProductDesc> {


    void updateById(TProductDesc desc);
}
