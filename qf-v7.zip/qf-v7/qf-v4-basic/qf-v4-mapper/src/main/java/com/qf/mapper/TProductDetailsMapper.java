package com.qf.mapper;

import com.qf.base.IBaseDao;
import com.qf.entity.TProductDetails;

public interface TProductDetailsMapper extends IBaseDao<TProductDetails> {
    int insert(TProductDetails record);

    int insertSelective(TProductDetails record);

    void updateById(TProductDetails details);
}