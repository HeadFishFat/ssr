package com.qf.entity;

import java.io.Serializable;

public class TProductDesc implements Serializable {
    private Long id;

    private Long pid;

    private String productDesc;

    public TProductDesc(Long id, Long pid, String productDesc) {
        this.id = id;
        this.pid = pid;
        this.productDesc = productDesc;
    }

    public TProductDesc() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc == null ? null : productDesc.trim();
    }
}