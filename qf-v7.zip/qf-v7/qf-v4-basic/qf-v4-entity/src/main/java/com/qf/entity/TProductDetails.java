package com.qf.entity;

import java.io.Serializable;

public class TProductDetails implements Serializable {

    private Long pid;

    private String model;

    private String specs;

    private Long voltage;

    private Long section;



    public TProductDetails(String model, String specs, Long voltage, Long section, Long pid) {
        this.model = model;
        this.specs = specs;
        this.voltage = voltage;
        this.section = section;
        this.pid = pid;
    }

    public TProductDetails() {
        super();
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model == null ? null : model.trim();
    }

    public String getSpecs() {
        return specs;
    }

    public void setSpecs(String specs) {
        this.specs = specs == null ? null : specs.trim();
    }

    public Long getVoltage() {
        return voltage;
    }

    public void setVoltage(Long voltage) {
        this.voltage = voltage;
    }

    public Long getSection() {
        return section;
    }

    public void setSection(Long section) {
        this.section = section;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }
}